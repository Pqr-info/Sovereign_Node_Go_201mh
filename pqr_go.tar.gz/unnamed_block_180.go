ctx := context.Background()
if err := streamClient.Connect(ctx); err != nil {
    log.Fatalf("could not establish connection: %v", err)
}