if isHalted {
    state.AwaitingReopen = true
    return Action{Type: "PASS", Reason: "Halted"}
}
// Upon Reopen, enforce a mandatory 1-minute cooling period before assessing OBI.
if state.JustReopened && timeSinceReopen < 1 * time.Minute {
    return Action{Type: "PASS", Reason: "Cooling period post-halt"}
}