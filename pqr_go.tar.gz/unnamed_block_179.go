import (
    "github.com/alpacahq/alpaca-trade-api-go/v3/marketdata/stream"
    "github.com/alpacahq/alpaca-trade-api-go/v3/marketdata"
)

// Define your feed and credentials
feed := "iex" // or "sip" if you have a premium subscription
apiKey := "YOUR_API_KEY"
apiSecret := "YOUR_API_SECRET"

// Initialize the client
streamClient := stream.NewStocksClient(
    feed,
    stream.WithCredentials(apiKey, apiSecret),
)