// Example logic in action handler
e.QueueTrade(pair.AssetA, -100, "SELL SHORT") 
e.QueueTrade(pair.AssetB, 100, "BUY")