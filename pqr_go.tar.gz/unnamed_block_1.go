if VIX < 45 && currentSpread < 100bps {
    return Action{Type: "PASS", Reason: "Market Normal - Let Grandaddy trade"}
}