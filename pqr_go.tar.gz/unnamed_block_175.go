type PairConfig struct {
	AssetA string
	AssetB string
	Mean   float64 // 20-day historical mean of the spread
	StdDev float64 // 20-day standard deviation of the spread
}

type ArbitrageEngine struct {
	Cobrowser      *CobrowserClient
	Firehose       *FirehoseTeleporter
	ActivePairs    []PairConfig
	RealTimePrices map[string]float64 // Updated continuously by Alpaca WebSocket
}