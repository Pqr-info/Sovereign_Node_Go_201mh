// MarketSniperTick is the high-speed algorithm resurrected from the user's github
func (e *ArbitrageEngine) MarketSniperTick() {
	for _, pair := range e.ActivePairs {
		priceA := e.RealTimePrices[pair.AssetA]
		priceB := e.RealTimePrices[pair.AssetB]

		if priceA == 0 || priceB == 0 {
			continue // Awaiting real-time tick
		}

		spread := priceA - priceB
		zScore := (spread - pair.Mean) / pair.StdDev

		if zScore > 2.0 {
			// Asset A is overvalued relative to B
			if e.WhaleWatcherConfirm(pair.AssetA, pair.AssetB) {
				log.Printf("[MarketSniper] 🎯 Pair %s/%s Z-Score: %.2f! Executing Arbitrage.", pair.AssetA, pair.AssetB, zScore)
				e.ExecuteAlpacaLeg(pair.AssetB, alpaca.Buy) // Long undervalued
				e.QueueSchwabTrade(pair.AssetA, 50)             // Short overvalued on Schwab
			}
		} else if zScore < -2.0 {
			// Asset A is undervalued relative to B
			if e.WhaleWatcherConfirm(pair.AssetA, pair.AssetB) {
				log.Printf("[MarketSniper] 🎯 Pair %s/%s Z-Score: %.2f! Executing Arbitrage.", pair.AssetA, pair.AssetB, zScore)
				e.ExecuteAlpacaLeg(pair.AssetA, alpaca.Buy) // Long undervalued
				e.QueueSchwabTrade(pair.AssetB, 50)             // Short overvalued on Schwab
			}
		}
	}
}

// WhaleWatcherConfirm checks volume constraints to ensure we aren't trading into a fakeout
func (e *ArbitrageEngine) WhaleWatcherConfirm(assetA, assetB string) bool {
	volA := e.RealTimeVolume[assetA]
	volB := e.RealTimeVolume[assetB]
	// Basic resurrected logic: Reject trades if there's no liquidity
	if volA < 1.0 || volB < 1.0 {
		return false
	}
	return true
}