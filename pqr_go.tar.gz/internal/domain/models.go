package domain

import (
	"time"

	"github.com/google/uuid"
)

type ErrorSolutionRecord struct {
	SignatureHash string
	SuccessRate   float64
}

type SynthesizedFix struct {
	SignatureHash string
	FixPayload    map[string]interface{}
}

func (f SynthesizedFix) ApplyToCommand(cmd string) string {
	if f.FixPayload == nil {
		return cmd
	}

	if rep, ok := f.FixPayload["replace"].(string); ok {
		return rep
	}

	if pre, ok := f.FixPayload["prepend"].(string); ok {
		return pre + " " + cmd
	}

	if app, ok := f.FixPayload["append"].(string); ok {
		return cmd + " " + app
	}

	return cmd
}

// RelationshipType defines how two tickets are connected
type RelationshipType string

const (
	RelEvolution   RelationshipType = "EVOLUTION"
	RelConsequence RelationshipType = "CONSEQUENCE"
	RelContext     RelationshipType = "CONTEXT"
	RelGenesis     RelationshipType = "GENESIS"
)

// FabricTicket represents the metadata and state of a single memory unit
type FabricTicket struct {
	ID              uuid.UUID `json:"id"`
	LayerID         int       `json:"layer_id"`
	CreatorAgentID  string    `json:"creator_agent_id"`
	Status          string    `json:"status"`
	Iteration       int       `json:"iteration"`
	EscalationLevel int       `json:"escalation_level"`
	Resolution      string    `json:"resolution,omitempty"`
	ResolvedBy      string    `json:"resolved_by,omitempty"`
	AssignedTo      string    `json:"assigned_to,omitempty"`
	CreatedAt       time.Time `json:"created_at"`
	UpdatedAt       time.Time `json:"updated_at"`
}

// FabricContent holds the actual payload and forensic hashes of a ticket
type FabricContent struct {
	TicketID       uuid.UUID              `json:"ticket_id"`
	IntentBlob     map[string]interface{} `json:"intent_blob"`
	StateVector    []float64              `json:"state_vector"`
	ConsensusScore float64                `json:"consensus_score"`
	RawContent     []byte                 `json:"raw_content"`
	SummaryHash    string                 `json:"summary_hash"`
	PayloadHash    string                 `json:"payload_hash"`
	FailedAttempts []string               `json:"failed_attempts,omitempty"`
}

// StateSnapshot tracks the latest shared editor/agent state for a scope and owner.
type StateSnapshot struct {
	Scope     string                 `json:"scope"`
	Owner     string                 `json:"owner"`
	AgentID   string                 `json:"agent_id"`
	Source    string                 `json:"source"`
	Payload   map[string]interface{} `json:"payload"`
	Checksum  string                 `json:"checksum"`
	UpdatedAt time.Time              `json:"updated_at"`
}

// AgentMessage is a lightweight durable message that can be exchanged between active agents.
type AgentMessage struct {
	ID        uuid.UUID              `json:"id"`
	Scope     string                 `json:"scope"`
	Sender    string                 `json:"sender"`
	Receiver  string                 `json:"receiver"`
	Kind      string                 `json:"kind"`
	Body      string                 `json:"body"`
	Payload   map[string]interface{} `json:"payload,omitempty"`
	CreatedAt time.Time              `json:"created_at"`
}

// Agent represents an autonomous entity in the swarm
type Agent struct {
	ID       string                 `json:"id"`
	Role     string                 `json:"role"`
	Level    int                    `json:"level"`
	Metadata map[string]interface{} `json:"metadata"`
}

// AuditEntry records a forensic trail of changes to a ticket
type AuditEntry struct {
	ID        uuid.UUID              `json:"id"`
	TicketID  uuid.UUID              `json:"ticket_id"`
	AgentID   string                 `json:"agent_id"`
	Action    string                 `json:"action"`
	OldValue  map[string]interface{} `json:"old_value,omitempty"`
	NewValue  map[string]interface{} `json:"new_value,omitempty"`
	CreatedAt time.Time              `json:"created_at"`
}

// User represents a human or system user for authentication
type User struct {
	ID          uuid.UUID `json:"id"`
	Username    string    `json:"username"`
	Email       string    `json:"email"`
	DisplayName string    `json:"display_name"`
	CreatedAt   time.Time `json:"created_at"`
}
