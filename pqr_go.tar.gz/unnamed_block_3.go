isDeepDiscount := currentPrice < dynamicVWAPLowerBand
isExhaustionWick := (currentVolume > 5 * avgVolume) && (closePrice > (high + low) / 2)
isOrderBookBullish := OBI_5Level > 0.40 // Huge institutional bid stepping in

if isDeepDiscount && isExhaustionWick && isOrderBookBullish {
    // CRITICAL: We NEVER execute a Market Order in 500bps spread conditions.
    // We post a passive LIMIT order exactly at the Best Bid + 1 tick.
    return Action{
        Type: "LIMIT_BUY", 
        Price: bestBid + tickSize, 
        TIF: "IOC" // Immediate or Cancel to avoid getting run over
    }
}